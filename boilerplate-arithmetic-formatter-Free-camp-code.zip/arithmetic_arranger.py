def arithmetic_arranger(problems, answer = False):

    #Create empty list for numbers and operator
    #Could use [] rather than list() to improve performance
    first_number = list()
    second_number = list()
    operator = list()

    #To grab the operator and operands seperately
    #The split() method splits a string into a list.
    for problem in problems:
        splits = problem.split()
        first_number.append(splits[0])
        second_number.append(splits[2])
        operator.append(splits[1])

    #Check if number of problems > 5
    if len(problems) > 5:
      return "Error: Too many problems."

    #check if the operator is only + or -  
    for i in range(len(operator)):
      if (operator[i] not in ("+", "-")):
        return "Error: Operator must be '+' or '-'."
              
    #Check number length and ensure it is only in digits
    # No need for .isdigit() == False as it accomplishes same thing as .isdigit()
    for i in range(len(first_number)):
      if not (first_number[i].isdigit() and second_number[i].isdigit()):
        return "Error: Numbers must only contain digits."
      elif len(first_number[i]) >= 5 or len(second_number[i]) >= 5:
        return "Error: Numbers cannot be more than four digits."

    #Create empty list for line format 
    first_line = list()
    second_line = list()
    third_line = list()
    fourth_line = list()

    #Creating the spacing for the operator and operand
    #format for the first line
    for i in range(len(first_number)):
        if len(first_number[i]) > len(second_number[i]):
            first_line.append("  " + first_number[i])
        else:
            first_line.append(" "*(len(second_number[i]) - len(first_number[i]) + 2) + first_number[i])

    #format for the second line
    for i in range(len(second_number)):
        if len(second_number[i]) > len(first_number[i]):
            second_line.append(operator[i] + " " + second_number[i])
        else:
            second_line.append(operator[i] + " "*(len(first_number[i]) - len(second_number[i]) +1 ) + second_number[i])

    #Format for dash lines
    #first or second operand can be passed in the len function
    for i in range(len(second_number)):
        third_line.append("-"*(max(len(first_number[i]), len(second_number[i])) + 2))

    #Create answer format for fourth line
    if answer:
        for i in range(len(first_number)):
            if operator[i] == "+":
                result = str(int(first_number[i]) + int(second_number[i]))
            else:
                result = str(int(first_number[i]) - int(second_number[i]))

    #Could also use this solution in the else statement of the fourth line - "fourth_line.append(" "*(max(len(first_operand[i]), len(second_operand[i])) - len(a) +2 ) + a)"
            if len(result) > max(len(first_number[i]), len(second_number[i])):
                fourth_line.append(" " + result)
            else:
                fourth_line.append("  " + result)
              
        #Spacing for each problem. Join function joins all items in a tuple into a string      
        formatted_problems = "    ".join(first_line) + "\n" + "    ".join(second_line) + "\n" + "    ".join(third_line) + "\n" + "    ".join(fourth_line)
    else:
        formatted_problems = "    ".join(first_line) + "\n" + "    ".join(second_line) + "\n" + "    ".join(third_line)

    return formatted_problems